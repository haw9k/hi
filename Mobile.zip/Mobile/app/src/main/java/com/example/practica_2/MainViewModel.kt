package com.example.practica_2

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class MainViewModel : ViewModel() {
    private var _users = MutableLiveData<MutableList<String>>()

    val users : LiveData<MutableList<String>> = _users

    init {
        _users.value = mutableListOf<String>()
    }

    fun setUsers(users: MutableList<String>){
        _users.value = users
    }
}
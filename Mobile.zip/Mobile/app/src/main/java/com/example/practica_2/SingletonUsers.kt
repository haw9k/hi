import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData

object UserRepository {
    private val _users = MutableLiveData<MutableList<String>>(mutableListOf())
    val users: LiveData<MutableList<String>> get() = _users

    fun addUser(user: String) {
        val currentList = _users.value ?: mutableListOf()
        currentList.add(user)
        _users.value = currentList
    }

    fun changeUser(user: String, userId: Int) {
        val currentList = _users.value ?: return
        if (userId in 0 until currentList.size) {
            currentList[userId] = user  // ПРОСТО ЗАМЕНЯЕМ ПО ИНДЕКСУ
            _users.value = currentList
        }
    }
}
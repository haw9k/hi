package com.example.practica_2

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val viewModel : MainViewModel by viewModels()
    lateinit var text_lable : TextView
    var usersLength : Int = 0
    var userIndex : Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        try {
            super.onCreate(savedInstanceState)
            enableEdgeToEdge()
            setContentView(R.layout.activity_main)

            var add_button : Button = findViewById<Button>(R.id.add_button)
            var change_button : Button = findViewById<Button>(R.id.change_button)
            text_lable = findViewById<TextView>(R.id.text_label)

            var previus_button : ImageButton = findViewById<ImageButton>(R.id.previus_button)
            var nex_button : ImageButton = findViewById<ImageButton>(R.id.next_button)

            previus_button.setOnClickListener {
                if(userIndex > 0){
                    userIndex = userIndex - 1
                    var users = UserRepository.users.value ?: listOf<String>()
                    text_lable.text = users[userIndex]
                    Log.i("users count", userIndex.toString())
                }else{
                    userIndex = usersLength - 1
                    var users = UserRepository.users.value ?: listOf<String>()
                    text_lable.text = users[userIndex]
                }
            }
            nex_button.setOnClickListener {
                if(userIndex < usersLength - 1){
                    userIndex = userIndex + 1
                    var users = UserRepository.users.value ?: listOf<String>()
                    text_lable.text = users[userIndex]
                    Log.i("users count", userIndex.toString())
                }else{
                    userIndex = 0
                    var users = UserRepository.users.value ?: listOf<String>()
                    text_lable.text = users[userIndex]
                }
            }

            UserRepository.users.observe(this){ users ->
                viewModel.setUsers(users)
                usersLength = users.count()
            }

            viewModel.users.observe(this) { users ->
                if (users.isEmpty()) {
                    text_lable.text = "Пользователя нет"
                } else {
                    text_lable.text = users[userIndex].toString()
                }
            }

            change_button.setOnClickListener {
                val intent = Intent(this, SecondActivity::class.java)
                intent.putExtra("type", "change")
                intent.putExtra("userIndex", userIndex)
                intent.putExtra("usersLen", usersLength)
                startActivity(intent)
            }

            add_button.setOnClickListener {
                val intent = Intent(this, SecondActivity::class.java)
                intent.putExtra("type", "add")
                startActivity(intent)
            }

        }catch (e : Exception){
            Log.e("Main activity", e.toString())
        }
    }

}
package com.example.practica_2

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputLayout

class SecondActivity: AppCompatActivity() {

    private val viewModel : MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_second)

        var create_button : Button = findViewById<Button>(R.id.create_button)
        var type = intent.getStringExtra("type")
        var userIndex = intent.getIntExtra("userIndex", -1)
        var userLen = intent.getIntExtra("usersLen", 0)

        if(userLen == 0 && type == "change"){
            finish()
        }

        var name_editor : EditText = findViewById<EditText>(R.id.name_editor)
        var second_name : EditText = findViewById<EditText>(R.id.second_name_editor)
        var last_name : EditText = findViewById<EditText>(R.id.last_name_editor)
        var age : EditText = findViewById<EditText>(R.id.age_editor)

        // Подстановка данных при изменении
        if (type == "change" && userIndex != -1) {
            val currentUsers = UserRepository.users.value
            if (userIndex in 0 until (currentUsers?.size ?: 0)) {
                val currentUser = currentUsers!![userIndex]
                // Разбиваем строку на составляющие
                val parts = currentUser.split(" ")
                if (parts.size >= 4) {
                    name_editor.setText(parts[0])       // Имя
                    second_name.setText(parts[1])       // Фамилия
                    last_name.setText(parts[2])         // Отчество
                    age.setText(parts[3])               // Возраст
                }
            }
        }

        fun validateFields(): Boolean {
            var isValid = true

            // Сброс подсветки
            name_editor.background.setTint(0xFF000000.toInt()) // Черный бордер
            second_name.background.setTint(0xFF000000.toInt())
            last_name.background.setTint(0xFF000000.toInt())
            age.background.setTint(0xFF000000.toInt())

            if (name_editor.text.toString().trim().isEmpty()) {
                name_editor.background.setTint(0xFFFF0000.toInt()) // Красный бордер
                Toast.makeText(this, "Пожалуйста, введите имя", Toast.LENGTH_SHORT).show()
                name_editor.requestFocus()
                isValid = false
            }
            else if (second_name.text.toString().trim().isEmpty()) {
                second_name.background.setTint(0xFFFF0000.toInt())
                Toast.makeText(this, "Пожалуйста, введите фамилию", Toast.LENGTH_SHORT).show()
                second_name.requestFocus()
                isValid = false
            }
            else if (last_name.text.toString().trim().isEmpty()) {
                last_name.background.setTint(0xFFFF0000.toInt())
                Toast.makeText(this, "Пожалуйста, введите отчество", Toast.LENGTH_SHORT).show()
                last_name.requestFocus()
                isValid = false
            }
            else if (age.text.toString().trim().isEmpty()) {
                age.background.setTint(0xFFFF0000.toInt())
                Toast.makeText(this, "Пожалуйста, введите возраст", Toast.LENGTH_SHORT).show()
                age.requestFocus()
                isValid = false
            }


            return isValid
        }

        if(type == "add"){
            create_button.text = "Добавить"
            create_button.setBackgroundColor(0xFF3A8513.toInt())

            create_button.setOnClickListener {
                // ✅ ПРОВЕРКА ПЕРЕД ДОБАВЛЕНИЕМ
                if (!validateFields()) {
                    return@setOnClickListener // Не добавляем если проверка не пройдена
                }

                UserRepository.addUser("${name_editor.text} ${second_name.text} ${last_name.text} ${age.text}")
                finish()
            }
        } else {
            create_button.text = "Изменить"
            create_button.setBackgroundColor(0xFF2E2F2D.toInt())

            create_button.setOnClickListener {
                // ✅ ПРОВЕРКА ПЕРЕД ИЗМЕНЕНИЕМ
                if (!validateFields()) {
                    return@setOnClickListener // Не изменяем если проверка не пройдена
                }

                Log.i("UserINFO", userIndex.toString())
                Log.i("UserINFO", "${name_editor.text} ${second_name.text} ${last_name.text} ${age.text}")
                UserRepository.changeUser(
                    "${name_editor.text} ${second_name.text} ${last_name.text} ${age.text}",
                    userIndex
                )
                finish()
            }
        }
    }
}
import androidx.lifecycle.ViewModel

class ContactViewModel : ViewModel() {
    var surname: String = "Иванов"
    var name: String = "Иван"
    var patronymic: String = "Иванович"
    var phone: String = "8 (999) 999-99-99"

    fun getFullName(): String {
        return "$surname $name $patronymic\n$phone"
    }
}

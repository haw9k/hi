import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val vm: ContactViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val tvContact: TextView = findViewById(R.id.tvContact)
        val btnEdit: Button = findViewById(R.id.btnEdit)

        tvContact.text = vm.getFullName()

        btnEdit.setOnClickListener {
            val intent = Intent(this, EditActivity::class.java)
            startActivity(intent)
        }
    }

    override fun onResume() {
        super.onResume()
        val tvContact: TextView = findViewById(R.id.tvContact)
        tvContact.text = vm.getFullName()
    }
}

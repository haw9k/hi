import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity

class EditActivity : AppCompatActivity() {

    private val vm: ContactViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit)

        val etSurname: EditText = findViewById(R.id.etSurname)
        val etName: EditText = findViewById(R.id.etName)
        val etPatronymic: EditText = findViewById(R.id.etPatronymic)
        val etPhone: EditText = findViewById(R.id.etPhone)
        val btnSave: Button = findViewById(R.id.btnSave)

        // Заполняем текущими значениями
        etSurname.setText(vm.surname)
        etName.setText(vm.name)
        etPatronymic.setText(vm.patronymic)
        etPhone.setText(vm.phone)

        btnSave.setOnClickListener {
            vm.surname = etSurname.text.toString()
            vm.name = etName.text.toString()
            vm.patronymic = etPatronymic.text.toString()
            vm.phone = etPhone.text.toString()
            finish() // вернуться на главный экран
        }
    }
}
